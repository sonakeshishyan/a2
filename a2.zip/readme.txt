--Readme document for *author*--

1. How many assignment points do you believe you completed (replace the *'s with your numbers)?

*/20
- 2/2 Tweet dates
- 3/3 Tweet categories
- 3/3 User-written tweets
- 3/3 Determining activity type and distance
- 3/3 Graphing activities by distance
- */3 Implementing the search box
- */3 Populating the table

2. How long, in hours, did it take you to complete this assignment?
25


3. What online resources did you consult when completing this assignment? (list sites like StackOverflow or specific URLs for tutorials, etc.)
https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/String/includes
https://www.w3schools.com/jsref/jsref_includes.asp
https://www.geeksforgeeks.org/change-an-element-class-javascript/#
https://mathjs.org/docs/reference/functions/format.html
https://www.w3schools.com/jsref/jsref_substring.asp
https://www.geeksforgeeks.org/java-string-trim-method-example/
https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Array/sort
https://www.freecodecamp.org/news/how-to-convert-a-string-to-a-number-in-javascript/
https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Date/getDay
https://www.javascripttutorial.net/javascript-dom/javascript-input-event/
https://vega.github.io/vega-lite/docs/data.html#inline
https://vega.github.io/vega-lite/tutorials/explore.html
https://stackoverflow.com/questions/2788191/how-to-check-whether-a-button-is-clicked-by-using-javascript






4. What classmates or other individuals did you consult as part of this assignment? What did you discuss?

N/A

5. Is there anything special we need to know in order to run your code?

N/A